var colors =  generateRandomColors(6) ;

var squares = document.querySelectorAll(".square");
var pickedColor = pickColor() ;
var colorDisplay = document.getElementById("colorDisplay") ;
var messageDisplay = document.getElementById("message") ;
var h1 = document.querySelector ("h1") ;
var resetButton = document.getElementById("reset") ;
var rematch = document.getElementById("rematch");
var easyButton = document.getElementById("easyButton") ;
var hardButton = document.getElementById("hardButton") ;
var hardMode = true ;

//Easy Button
easyButton.addEventListener("click", function (){
	hardButton.classList.remove("selected");
	easyButton.classList.add("selected");
	hardMode = false ;
	h1.style.backgroundColor = "steelblue" ;

	//Generate 3 new colors
	colors = generateRandomColors(3) ;

	//Pick one color form the 3
	pickedColor = pickColor() ;

	//Update display with picked color
	colorDisplay.textContent = pickedColor ;

	//Update the 3 squares
	for(var i = 0; i < squares.length; i++)
	{
		if (colors[i])
			{
				squares[i].style.backgroundColor = colors[i] ;	
			}
	//Hide the bottom 3 squares (background color)
		else
			{
				squares[i].style.display = "none" ;
			}
};


});

//Hard Button
hardButton.addEventListener("click", function (){
	hardButton.classList.add("selected");
	easyButton.classList.remove("selected");
	hardMode = true ;
	h1.style.backgroundColor = "steelblue" ;

	//Generate 6 new colors
	colors = generateRandomColors(6) ;

	//Pick one color from the 6
	pickedColor = pickColor() ;

	//Update display with picked color
	colorDisplay.textContent = pickedColor ;

	//Update the 6 squares
	for(var i = 0; i < squares.length; i++)
	{
		squares[i].style.backgroundColor = colors[i] ;
		squares[i].style.display = "block" ;
	}
});

colorDisplay.textContent = pickedColor;

//Select the div/squares
//Loop through each square
//Assign a color and move to the next square
for (var i = 0; i < squares.length; i++ )
{
	//Add initial colors to squares
	squares[i].style.backgroundColor = colors[i] ; 

	//Add click Event Listener to squares
	squares[i].addEventListener("click", function(){

	//Grab color of "clicked square"
	var clickedColor = this.style.backgroundColor;
	console.log(clickedColor + "    " + pickedColor) ;

	//And compare to "picked color"
	if (clickedColor === pickedColor)
		{
			messageDisplay.textContent = "Correct!!" ;
			changeColors (clickedColor) ;
			h1.style.backgroundColor = clickedColor ;
			resetButton.textContent = "PLAY AGAIN?" ;

		}
	else
		{
			this.style.backgroundColor = "#232323" ;
			messageDisplay.textContent = "Try Again!" ;

		}	

	}) ;
};


//Reset Button
resetButton.addEventListener("click", function () {
	
	//Generate new colors
	if(hardMode == true)
	{
		colors = generateRandomColors(6) ;

		//Update the 6 squares
		for(var i = 0; i < squares.length; i++)
		{
			squares[i].style.backgroundColor = colors[i] ;
			squares[i].style.display = "block" ;
		}
	} 

	
	else (hardMode == false)
	{
		colors = generateRandomColors(3) ;
	} 
	
	
	//"Pick" new random color
	pickedColor = pickColor() ;

	//Change colorDisplay to match new color
	colorDisplay.textContent = pickedColor ;

	//Change colors of squares
	for (var i = 0; i < squares.length; i++ )
	{
	//Add initial colors to squares
	squares[i].style.backgroundColor = colors[i] ;
	}

	h1.style.backgroundColor = "steelblue" ;
	messageDisplay.textContent = "" ;
	this.textContent = "New Colors" ;
	}) ; 



function changeColors(color) 
{
	//Loop through all squares
	//Then change each color to match "picked color"
	for (var i = 0; i < squares.length; i++ )
		{
			squares[i].style.backgroundColor = color ;
			console.log("All colors are the same!	") ;
		}

} ;

function pickColor()
{
	var random = Math.floor(Math.random() * colors.length) ;
	return colors[random] ; 
};

function generateRandomColors(num)
{
	//Make an array
	var arr = [] ;

	//Add "num" random colors to the array
	for (var i = 0; i < num ; i++)
		{
			arr.push(randomColor()) ;
		}
	//return that array
	return arr ;
}

function randomColor ()
{
	//Pick a RED from 0-255
	var red = Math.floor(Math.random() * 256) ;
	//Pick a GREEN from 0-255
	var green = Math.floor(Math.random() * 256) ;
	//Pick a BLUE from 0-255
	var blue = Math.floor(Math.random() * 256) ;

	//Compile final RGB result
	return rgb = "rgb(" + red + ", " + green + ", " + blue + ")" ;
};

