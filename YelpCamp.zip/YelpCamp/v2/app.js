var express     = require("express"),
    app         = express(),
    bodyParser  = require("body-parser"),
    mongoose    = require("mongoose");
    
mongoose.connect("mongodb://localhost:27017/yelp_camp", { useNewUrlParser: true });

//Setup the Campgrounds SCHEMA
var campgroundSchema = new mongoose.Schema({
    name: String,
    image: String
}); 

var Campground = mongoose.model("Campground", campgroundSchema);   //Campground OBJECT 

// Campground.create({
//     name: "Smoky Mountains", 
//     image: "https://www.visitmysmokies.com/wp-content/uploads/2013/03/Sunset-Camping.jpg"
// }, function(err, campground){
//     if(err)
//     {
//         console.log(err);
//     }
//     else
//     {
//         console.log("A new campground has been created!");
//         console.log(campground) ;
//     }
// });


//Array containing ALL campgrounds
var campgrounds = [
            {name: "Smoky Mountains", image: "https://www.visitmysmokies.com/wp-content/uploads/2013/03/Sunset-Camping.jpg"},
            {name: "Yosemite National Park", image: "https://www.adventure-journal.com/wp-content/uploads/2014/06/adventure-journal-aj-list-bad-camping-reviews.jpg"},
            {name: "The Grand Canyon", image: "https://2bweyl1gaa562a4c2g3ryca6-wpengine.netdna-ssl.com/wp-content/uploads/2016/06/grand-canyon-upper%C2%A9WRE-99-1500x630.jpg"},
            {name: "Smoky Mountains", image: "https://www.visitmysmokies.com/wp-content/uploads/2013/03/Sunset-Camping.jpg"},
            {name: "Yosemite National Park", image: "https://www.adventure-journal.com/wp-content/uploads/2014/06/adventure-journal-aj-list-bad-camping-reviews.jpg"},
            {name: "The Grand Canyon", image: "https://2bweyl1gaa562a4c2g3ryca6-wpengine.netdna-ssl.com/wp-content/uploads/2016/06/grand-canyon-upper%C2%A9WRE-99-1500x630.jpg"}
           
        ]

app.use(bodyParser.urlencoded({extended: true}));  //Include body-parser in the project
app.set("view engine", "ejs");                     //configure view-engine to expect ".ejs"

//Landing Page Route ("/")
app.get("/", function(req, res){
    res.render("landingPage");
    
}); 

//INDEX- Show all campgrounds
//Camp Grounds Route ("/campGrounds")
app.get("/campgrounds", function(req, res){
    
    //GET all campgrounds from the database
    Campground.find({}, function(err, allCampgrounds){
        if(err)
        {
            console.log(err) ;
        }
        else
        {
            res.render("campgrounds", {campgrounds: allCampgrounds}); 
        }
    })

        
});

//CREATE- Add new campground to database 
//Add New Campground Route
app.post("/campgrounds", function(req, res){
    var name = req.body.newName;                            //Collecting "name" data from the form
    var image = req.body.newURL;                         //Collecting "image url" data from the form
    var newCampground = {name: name, image: image } ;     //Temporary variable containing data of newCampground
    
//CREATE a new campground and ADD it to the database
    Campground.create(newCampground, function(err, newCreated){
         if(err)
         {
             console.log(err);
         }
        else
        {
             res.redirect("/campgrounds");                       //Redirect to the "updated" campgrounds page
        }
    });
}); 

//CREATE- Show form to create new campground
//Form containing data about New Campground
app.get("/campgrounds/new", function(req, res){
    res.render("newCampground");
}); 

app.listen(process.env.PORT, process.env.IP, function(){
    console.log("The YelpCamp server is online and ready!");
});