
====================================================================
                                Show Page
====================================================================

1 Review the RESTful Routes we've done so far
2 Add a descriptioin to our capmground model
3 Show db.collection.drop() 
4 Add a show Route/Template 

====================================================================
                            RESTful ROUTES
====================================================================


Name                url        Method       Description           
====================================================================
1 INDEX Route       /dogs       GET     Display LIST of all dogs
2 NEW Route         /dogs/new   GET     Displays FORM to create new dog
3 CREATE Route      /dogs       POST    Add new dog to database
4 SHOW              /dogs/:id   GET     Shows info about one dog 
