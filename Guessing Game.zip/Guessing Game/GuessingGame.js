//Create Secret Number
var SecretNumber = 4 ;

//Ask user to guess
var guess = Number(prompt("Guess a number:")) ;

//Check if guess is correct
if (guess === SecretNumber)
{
	alert("Congratulations, that's correct!") ;
} 
else if(guess < SecretNumber)
{
	alert("Too low, guess again.") ;
}

else if(guess> SecretNumber)
{
	alert("Too high, guess again.") ;
} 

