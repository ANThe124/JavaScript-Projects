// LINE-THROUGH AND FADE
//Check-off a specific <li> by clicking
//Change its color
//Add line-through effect
$("ul").on("click", "li", function(){
	$(this).toggleClass("completed");
}) ;	

//DELETE TO-DO
	//Click on X to delete to-do
$("ul").on("click", "span", function(event){
	console.log("A span has been clicked!");
	event.stopPropagation() ;

	//Fade-out and remove
	$(this).parent().fadeOut(function(){
		$(this).remove() ;
	});
});
	

//ADD A TO-DO
$("input[type='text']").keypress(function(event){
	if(event.which===13){
		//Extract the input val
		var todoText = $(this).val();
		var newSpan = $(this).val("") ;

		//Create a new li to the ul
		$("ul").append("<li><span><i class='fa fa-trash-alt'></i> </span>"+todoText+"</li>");
	}
});

$(".fa-power-off").click(function(){
	$("input[type='text']").fadeToggle();

})